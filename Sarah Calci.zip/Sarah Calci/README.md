# Calculator

A simple Calculator App built with HTML, CSS, and JavaScript. It also has a Dark Mode.

